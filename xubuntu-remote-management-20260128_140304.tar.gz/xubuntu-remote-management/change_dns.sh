#!/bin/bash
set +e
for host in $(cat hosts.txt)
do
    echo "Processing $host..."
    sshpass -p 'sweetcom' ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 sweetagent@"$host" 'echo sweetcom | sudo -S bash -c "
        CONNECTION=\$(nmcli -t -f NAME,TYPE,DEVICE con show --active | grep ethernet | head -n1 | cut -d: -f1)
        if [ -z \"\$CONNECTION\" ]; then
            echo \"No active ethernet connection found\"
            exit 1
        fi
        echo \"Active connection: \$CONNECTION\"
        nmcli con mod \"\$CONNECTION\" ipv4.dns \"1.1.1.1 8.8.8.8 205.251.242.103\"
        nmcli con mod \"\$CONNECTION\" ipv4.ignore-auto-dns yes
        nmcli con down \"\$CONNECTION\" && nmcli con up \"\$CONNECTION\"
    "' || true
    if [ $? -eq 0 ]; then
        echo "$host: SUCCESS"
    else
        echo "$host: FAILED"
    fi
done
echo "All hosts processed."
