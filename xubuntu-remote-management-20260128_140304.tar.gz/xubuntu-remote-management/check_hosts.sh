#!/bin/bash
set +e

echo "=== Checking Host Status ==="
echo ""

if [ ! -f "hosts.txt" ]; then
    echo "ERROR: hosts.txt not found!"
    exit 1
fi

ONLINE=0
OFFLINE=0
TOTAL=0

# Create results file with timestamp
RESULTS_FILE="host_status_$(date +%Y%m%d_%H%M%S).txt"
echo "Host Status Check - $(date)" > "$RESULTS_FILE"
echo "======================================" >> "$RESULTS_FILE"
echo "" >> "$RESULTS_FILE"

while read -r host; do
    # Skip empty lines and comments
    if [ -z "$host" ] || [[ "$host" =~ ^# ]]; then
        continue
    fi

    ((TOTAL++))

    # Ping with 1 second timeout
    ping -c 1 -W 1 "$host" &>/dev/null

    if [ $? -eq 0 ]; then
        echo "✓ $host - ONLINE"
        echo "✓ $host - ONLINE" >> "$RESULTS_FILE"
        ((ONLINE++))
    else
        echo "✗ $host - OFFLINE"
        echo "✗ $host - OFFLINE" >> "$RESULTS_FILE"
        ((OFFLINE++))
    fi
done < hosts.txt

echo "" | tee -a "$RESULTS_FILE"
echo "======================================" | tee -a "$RESULTS_FILE"
echo "Summary:" | tee -a "$RESULTS_FILE"
echo "  Total hosts: $TOTAL" | tee -a "$RESULTS_FILE"
echo "  Online: $ONLINE" | tee -a "$RESULTS_FILE"
echo "  Offline: $OFFLINE" | tee -a "$RESULTS_FILE"
echo "" | tee -a "$RESULTS_FILE"
echo "Results saved to: $RESULTS_FILE"
