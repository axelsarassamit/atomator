#!/bin/bash
set +e

for host in $(cat hosts.txt)
do
    echo "Processing $host..."
    sshpass -p 'sweetcom' ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 sweetagent@"$host" 'echo sweetcom | sudo -S bash -c "
        echo \"Cleaning up system on $host...\"

        # Clean trash for sweetagent user
        echo \"Emptying trash...\"
        rm -rf /home/sweetagent/.local/share/Trash/files/* 2>/dev/null
        rm -rf /home/sweetagent/.local/share/Trash/info/* 2>/dev/null

        # Clean browser cache (Chromium)
        echo \"Cleaning Chromium cache...\"
        rm -rf /home/sweetagent/.cache/chromium/* 2>/dev/null

        # Clean browser cache (Firefox)
        echo \"Cleaning Firefox cache...\"
        rm -rf /home/sweetagent/.cache/mozilla/* 2>/dev/null

        # Clean thumbnail cache
        echo \"Cleaning thumbnail cache...\"
        rm -rf /home/sweetagent/.cache/thumbnails/* 2>/dev/null

        # Clean temporary files
        echo \"Cleaning temporary files...\"
        rm -rf /home/sweetagent/.cache/tmp/* 2>/dev/null
        rm -rf /home/sweetagent/tmp/* 2>/dev/null
        rm -rf /home/sweetagent/.tmp/* 2>/dev/null

        # Clean old log files in home directory
        echo \"Cleaning old log files...\"
        find /home/sweetagent -name \"*.log\" -type f -mtime +30 -delete 2>/dev/null

        # Clean APT cache
        echo \"Cleaning APT cache...\"
        apt-get clean
        apt-get autoclean

        # Remove old kernels (keep current and one previous)
        echo \"Removing old kernels...\"
        apt-get autoremove -y --purge

        # Clean system tmp
        echo \"Cleaning /tmp...\"
        find /tmp -type f -atime +7 -delete 2>/dev/null

        # Clean journal logs older than 7 days
        echo \"Cleaning old journal logs...\"
        journalctl --vacuum-time=7d 2>/dev/null || true

        # Show disk usage after cleanup
        DISK_FREE=\$(df -h / | tail -n1 | awk '\''{print \$4}'\'' )
        echo \"✓ Cleanup complete\"
        echo \"✓ Available disk space: \$DISK_FREE\"
    "' || true
    if [ $? -eq 0 ]; then
        echo "$host: SUCCESS"
    else
        echo "$host: FAILED"
    fi
done
echo "All hosts processed."
