#!/bin/bash
set +e

# Create results file with timestamp
RESULTS_FILE="hardware_info_$(date +%Y%m%d_%H%M%S).txt"
echo "=== Hardware Information Collection ===" > "$RESULTS_FILE"
echo "Date: $(date)" >> "$RESULTS_FILE"
echo "======================================" >> "$RESULTS_FILE"
echo "" >> "$RESULTS_FILE"

for host in $(cat hosts.txt)
do
    echo "Processing $host..."

    HW_INFO=$(sshpass -p 'sweetcom' ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 sweetagent@"$host" 'echo sweetcom | sudo -S bash -c "
        # Get hostname
        HOSTNAME=\$(hostname -s)

        # Get manufacturer
        MANUFACTURER=\$(dmidecode -s system-manufacturer 2>/dev/null | head -n1 | tr -d '\''\n'\'' | sed '\''s/^ *//;s/ *$//'\'' )
        [ -z \"\$MANUFACTURER\" ] && MANUFACTURER=\"Unknown\"

        # Get product/model name
        MODEL=\$(dmidecode -s system-product-name 2>/dev/null | head -n1 | tr -d '\''\n'\'' | sed '\''s/^ *//;s/ *$//'\'' )
        [ -z \"\$MODEL\" ] && MODEL=\"Unknown\"

        # Get serial number
        SERIAL=\$(dmidecode -s system-serial-number 2>/dev/null | head -n1 | tr -d '\''\n'\'' | sed '\''s/^ *//;s/ *$//'\'' )
        [ -z \"\$SERIAL\" ] && SERIAL=\"Unknown\"

        # Get BIOS version
        BIOS=\$(dmidecode -s bios-version 2>/dev/null | head -n1 | tr -d '\''\n'\'' | sed '\''s/^ *//;s/ *$//'\'' )
        [ -z \"\$BIOS\" ] && BIOS=\"Unknown\"

        # Get CPU info
        CPU=\$(lscpu | grep \"Model name\" | cut -d: -f2 | sed '\''s/^ *//;s/ *$//'\'' | tr -d '\''\n'\'' )
        [ -z \"\$CPU\" ] && CPU=\"Unknown\"

        # Get total RAM
        TOTAL_RAM_KB=\$(grep MemTotal /proc/meminfo | awk '\''{print \$2}'\'' )
        TOTAL_RAM_GB=\$(echo \"scale=2; \$TOTAL_RAM_KB / 1024 / 1024\" | bc)

        # Get disk size
        DISK_SIZE=\$(lsblk -b -d -o SIZE,TYPE | grep disk | awk '\''{sum+=\$1} END {printf \"%.2f\", sum/1024/1024/1024}'\'' )

        echo \"\$HOSTNAME|\$MANUFACTURER|\$MODEL|\$SERIAL|\$BIOS|\$CPU|\$TOTAL_RAM_GB|\$DISK_SIZE\"
    "' 2>&1)

    if [ $? -eq 0 ] && [[ ! "$HW_INFO" =~ "command not found" ]]; then
        # Parse the result
        HOSTNAME=$(echo "$HW_INFO" | tail -n1 | cut -d'|' -f1)
        MANUFACTURER=$(echo "$HW_INFO" | tail -n1 | cut -d'|' -f2)
        MODEL=$(echo "$HW_INFO" | tail -n1 | cut -d'|' -f3)
        SERIAL=$(echo "$HW_INFO" | tail -n1 | cut -d'|' -f4)
        BIOS=$(echo "$HW_INFO" | tail -n1 | cut -d'|' -f5)
        CPU=$(echo "$HW_INFO" | tail -n1 | cut -d'|' -f6)
        RAM=$(echo "$HW_INFO" | tail -n1 | cut -d'|' -f7)
        DISK=$(echo "$HW_INFO" | tail -n1 | cut -d'|' -f8)

        if [ ! -z "$HOSTNAME" ]; then
            echo "--- $host ($HOSTNAME) ---" >> "$RESULTS_FILE"
            echo "  Manufacturer: $MANUFACTURER" >> "$RESULTS_FILE"
            echo "  Model: $MODEL" >> "$RESULTS_FILE"
            echo "  Serial Number: $SERIAL" >> "$RESULTS_FILE"
            echo "  BIOS Version: $BIOS" >> "$RESULTS_FILE"
            echo "  CPU: $CPU" >> "$RESULTS_FILE"
            echo "  RAM: ${RAM} GB" >> "$RESULTS_FILE"
            echo "  Disk Size: ${DISK} GB" >> "$RESULTS_FILE"
            echo "" >> "$RESULTS_FILE"
            echo "$host: SUCCESS - $MANUFACTURER $MODEL"
        else
            echo "--- $host ---" >> "$RESULTS_FILE"
            echo "  FAILED: Could not retrieve hardware info" >> "$RESULTS_FILE"
            echo "" >> "$RESULTS_FILE"
            echo "$host: FAILED - Could not parse info"
        fi
    else
        echo "--- $host ---" >> "$RESULTS_FILE"
        echo "  FAILED: Connection or command error" >> "$RESULTS_FILE"
        echo "" >> "$RESULTS_FILE"
        echo "$host: FAILED - $HW_INFO"
    fi
done

echo "======================================" >> "$RESULTS_FILE"
echo "Collection completed: $(date)" >> "$RESULTS_FILE"

echo ""
echo "All hosts processed."
echo "Results saved to: $RESULTS_FILE"
echo ""
echo "=== Summary ==="
cat "$RESULTS_FILE"
