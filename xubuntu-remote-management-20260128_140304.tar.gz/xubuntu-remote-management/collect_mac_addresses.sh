#!/bin/bash
set +e

# Create results file with timestamp
RESULTS_FILE="mac_addresses_$(date +%Y%m%d_%H%M%S).txt"
echo "=== MAC Addresses Collection ===" > "$RESULTS_FILE"
echo "Date: $(date)" >> "$RESULTS_FILE"
echo "======================================" >> "$RESULTS_FILE"
echo "" >> "$RESULTS_FILE"

for host in $(cat hosts.txt)
do
    echo "Processing $host..."

    MAC_INFO=$(sshpass -p 'sweetcom' ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 sweetagent@"$host" "
        # Get active ethernet connection device
        DEVICE=\$(nmcli -t -f DEVICE,TYPE con show --active | grep ethernet | head -n1 | cut -d: -f1)

        if [ -z \"\$DEVICE\" ]; then
            # Try alternative method - get device from default route
            DEVICE=\$(ip route | grep default | awk '{print \$5}' | head -n1)
        fi

        if [ -z \"\$DEVICE\" ]; then
            echo \"ERROR: No active ethernet device\"
            exit 1
        fi

        # Get MAC address
        MAC=\$(cat /sys/class/net/\$DEVICE/address 2>/dev/null | tr '[:lower:]' '[:upper:]')

        if [ -z \"\$MAC\" ]; then
            echo \"ERROR: Could not find MAC address\"
            exit 1
        fi

        # Get hostname
        HOSTNAME=\$(hostname -s)

        echo \"\$HOSTNAME|\$DEVICE|\$MAC\"
    " 2>&1)

    if [ $? -eq 0 ] && [[ ! "$MAC_INFO" =~ ERROR ]]; then
        # Parse the result
        HOSTNAME=$(echo "$MAC_INFO" | tail -n1 | cut -d'|' -f1)
        DEVICE=$(echo "$MAC_INFO" | tail -n1 | cut -d'|' -f2)
        MAC=$(echo "$MAC_INFO" | tail -n1 | cut -d'|' -f3)

        if [ ! -z "$MAC" ] && [ "$MAC" != "-" ]; then
            echo "$host | $HOSTNAME | $DEVICE | $MAC" >> "$RESULTS_FILE"
            echo "$host: SUCCESS - MAC: $MAC"
        else
            echo "$host | FAILED | - | -" >> "$RESULTS_FILE"
            echo "$host: FAILED - Could not parse MAC"
        fi
    else
        echo "$host | FAILED | - | -" >> "$RESULTS_FILE"
        echo "$host: FAILED - $MAC_INFO"
    fi
done

echo "" >> "$RESULTS_FILE"
echo "======================================" >> "$RESULTS_FILE"
echo "Collection completed: $(date)" >> "$RESULTS_FILE"

echo ""
echo "All hosts processed."
echo "Results saved to: $RESULTS_FILE"
echo ""
echo "=== Summary ==="
cat "$RESULTS_FILE"
