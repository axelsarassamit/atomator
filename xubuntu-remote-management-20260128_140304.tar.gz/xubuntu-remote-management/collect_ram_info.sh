#!/bin/bash
set +e

# Create results file with timestamp
RESULTS_FILE="ram_info_$(date +%Y%m%d_%H%M%S).txt"
echo "=== RAM Information Collection ===" > "$RESULTS_FILE"
echo "Date: $(date)" >> "$RESULTS_FILE"
echo "======================================" >> "$RESULTS_FILE"
echo "" >> "$RESULTS_FILE"

for host in $(cat hosts.txt)
do
    echo "Processing $host..."

    RAM_INFO=$(sshpass -p 'sweetcom' ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 sweetagent@"$host" "
        # Get hostname
        HOSTNAME=\$(hostname -s)

        # Get total RAM in GB
        TOTAL_RAM_KB=\$(grep MemTotal /proc/meminfo | awk '{print \$2}')
        TOTAL_RAM_GB=\$(echo \"scale=2; \$TOTAL_RAM_KB / 1024 / 1024\" | bc)

        # Get total RAM in MB for alternative display
        TOTAL_RAM_MB=\$(echo \"scale=0; \$TOTAL_RAM_KB / 1024\" | bc)

        # Get available RAM
        AVAILABLE_RAM_KB=\$(grep MemAvailable /proc/meminfo | awk '{print \$2}')
        AVAILABLE_RAM_GB=\$(echo \"scale=2; \$AVAILABLE_RAM_KB / 1024 / 1024\" | bc)

        # Get used RAM percentage
        USED_PERCENT=\$(echo \"scale=1; ((\$TOTAL_RAM_KB - \$AVAILABLE_RAM_KB) * 100) / \$TOTAL_RAM_KB\" | bc)

        echo \"\$HOSTNAME|\$TOTAL_RAM_GB|\$TOTAL_RAM_MB|\$AVAILABLE_RAM_GB|\$USED_PERCENT\"
    " 2>&1)

    if [ $? -eq 0 ]; then
        # Parse the result
        HOSTNAME=$(echo "$RAM_INFO" | tail -n1 | cut -d'|' -f1)
        TOTAL_GB=$(echo "$RAM_INFO" | tail -n1 | cut -d'|' -f2)
        TOTAL_MB=$(echo "$RAM_INFO" | tail -n1 | cut -d'|' -f3)
        AVAILABLE_GB=$(echo "$RAM_INFO" | tail -n1 | cut -d'|' -f4)
        USED_PERCENT=$(echo "$RAM_INFO" | tail -n1 | cut -d'|' -f5)

        if [ ! -z "$TOTAL_GB" ]; then
            echo "$host | $HOSTNAME | ${TOTAL_GB} GB (${TOTAL_MB} MB) | Available: ${AVAILABLE_GB} GB | Used: ${USED_PERCENT}%" >> "$RESULTS_FILE"
            echo "$host: SUCCESS - Total RAM: ${TOTAL_GB} GB"
        else
            echo "$host | FAILED | - | - | -" >> "$RESULTS_FILE"
            echo "$host: FAILED - Could not parse RAM info"
        fi
    else
        echo "$host | FAILED | - | - | -" >> "$RESULTS_FILE"
        echo "$host: FAILED - Connection error"
    fi
done

echo "" >> "$RESULTS_FILE"
echo "======================================" >> "$RESULTS_FILE"
echo "Collection completed: $(date)" >> "$RESULTS_FILE"

# Calculate statistics
echo "" >> "$RESULTS_FILE"
echo "=== Statistics ===" >> "$RESULTS_FILE"
TOTAL_SYSTEMS=$(grep -c "GB (" "$RESULTS_FILE")
if [ $TOTAL_SYSTEMS -gt 0 ]; then
    echo "Total systems: $TOTAL_SYSTEMS" >> "$RESULTS_FILE"

    # Sum all RAM
    TOTAL_RAM=$(grep "GB (" "$RESULTS_FILE" | awk -F'|' '{print $3}' | awk '{print $1}' | awk '{sum+=$1} END {printf "%.2f", sum}')
    echo "Combined RAM across all systems: ${TOTAL_RAM} GB" >> "$RESULTS_FILE"

    # Average RAM
    AVG_RAM=$(echo "scale=2; $TOTAL_RAM / $TOTAL_SYSTEMS" | bc)
    echo "Average RAM per system: ${AVG_RAM} GB" >> "$RESULTS_FILE"
fi

echo ""
echo "All hosts processed."
echo "Results saved to: $RESULTS_FILE"
echo ""
echo "=== Summary ==="
cat "$RESULTS_FILE"
