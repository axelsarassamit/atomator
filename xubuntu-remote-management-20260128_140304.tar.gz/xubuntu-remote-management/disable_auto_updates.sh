#!/bin/bash
set +e

for host in $(cat hosts.txt)
do
    echo "Processing $host..."
    sshpass -p 'sweetcom' ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 sweetagent@"$host" 'echo sweetcom | sudo -S bash -c "
        echo \"Disabling automatic updates...\"

        # Stop and disable unattended-upgrades service
        systemctl stop unattended-upgrades 2>/dev/null || true
        systemctl disable unattended-upgrades 2>/dev/null || true

        # Stop and disable apt-daily services
        systemctl stop apt-daily.timer 2>/dev/null || true
        systemctl disable apt-daily.timer 2>/dev/null || true
        systemctl stop apt-daily-upgrade.timer 2>/dev/null || true
        systemctl disable apt-daily-upgrade.timer 2>/dev/null || true
        systemctl stop apt-daily.service 2>/dev/null || true
        systemctl disable apt-daily.service 2>/dev/null || true
        systemctl stop apt-daily-upgrade.service 2>/dev/null || true
        systemctl disable apt-daily-upgrade.service 2>/dev/null || true

        # Configure APT to disable automatic updates
        cat > /etc/apt/apt.conf.d/20auto-upgrades << EOF
APT::Periodic::Update-Package-Lists \"0\";
APT::Periodic::Download-Upgradeable-Packages \"0\";
APT::Periodic::AutocleanInterval \"0\";
APT::Periodic::Unattended-Upgrade \"0\";
EOF

        # Disable unattended-upgrades
        cat > /etc/apt/apt.conf.d/50unattended-upgrades << EOF
Unattended-Upgrade::Allowed-Origins {};
Unattended-Upgrade::Automatic-Reboot \"false\";
EOF

        # Stop update-notifier
        killall update-notifier 2>/dev/null || true

        echo \"✓ Automatic updates disabled\"
        echo \"✓ All update timers stopped and disabled\"
        echo \"✓ Updates must now be run manually\"
    "' || true
    if [ $? -eq 0 ]; then
        echo "$host: SUCCESS"
    else
        echo "$host: FAILED"
    fi
done
echo "All hosts processed."
