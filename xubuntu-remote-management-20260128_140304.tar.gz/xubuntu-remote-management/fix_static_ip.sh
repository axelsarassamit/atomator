#!/bin/bash
set +e

for host in $(cat hosts.txt)
do
    echo "Processing $host..."
    sshpass -p 'sweetcom' ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 sweetagent@"$host" 'echo sweetcom | sudo -S bash -c "
        echo \"Checking network configuration for $host...\"

        # Get active ethernet connection
        CONNECTION=\$(nmcli -t -f NAME,TYPE,DEVICE con show --active | grep ethernet | head -n1 | cut -d: -f1)
        if [ -z \"\$CONNECTION\" ]; then
            echo \"No active ethernet connection found\"
            exit 1
        fi
        echo \"Active connection: \$CONNECTION\"

        # Get current IP address
        CURRENT_IP=\$(ip -4 addr show | grep inet | grep -v 127.0.0.1 | awk '\''{print \$2}'\'' | cut -d/ -f1 | head -n1)
        if [ -z \"\$CURRENT_IP\" ]; then
            echo \"No IP address found\"
            exit 1
        fi
        echo \"Current IP: \$CURRENT_IP\"

        # Get current gateway
        GATEWAY=\$(ip route | grep default | awk '\''{print \$3}'\'' | head -n1)
        if [ -z \"\$GATEWAY\" ]; then
            echo \"No gateway found\"
            exit 1
        fi
        echo \"Gateway: \$GATEWAY\"

        # Get netmask/prefix (assuming /24)
        PREFIX=\$(ip -4 addr show | grep inet | grep -v 127.0.0.1 | awk '\''{print \$2}'\'' | cut -d/ -f2 | head -n1)
        if [ -z \"\$PREFIX\" ]; then
            PREFIX=24
        fi
        echo \"Network prefix: /\$PREFIX\"

        # Set to manual/static IP
        echo \"Setting connection to manual with static IP...\"
        nmcli con mod \"\$CONNECTION\" ipv4.method manual
        nmcli con mod \"\$CONNECTION\" ipv4.addresses \"\$CURRENT_IP/\$PREFIX\"
        nmcli con mod \"\$CONNECTION\" ipv4.gateway \"\$GATEWAY\"
        nmcli con mod \"\$CONNECTION\" ipv4.dns \"1.1.1.1 8.8.8.8 205.251.242.103\"
        nmcli con mod \"\$CONNECTION\" ipv4.ignore-auto-dns yes

        # Restart connection to apply changes
        nmcli con down \"\$CONNECTION\" && nmcli con up \"\$CONNECTION\"

        echo \"✓ Connection set to MANUAL (static IP)\"
        echo \"✓ IP: \$CURRENT_IP/\$PREFIX\"
        echo \"✓ Gateway: \$GATEWAY\"
        echo \"✓ DNS: 1.1.1.1, 8.8.8.8, 205.251.242.103\"
    "' || true
    if [ $? -eq 0 ]; then
        echo "$host: SUCCESS"
    else
        echo "$host: FAILED"
    fi
done
echo "All hosts processed."
