#!/bin/bash
set +e

for host in $(cat hosts.txt)
do
    echo "Processing $host..."
    sshpass -p 'sweetcom' ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 sweetagent@"$host" 'echo sweetcom | sudo -S bash -c "
        echo \"Installing Firefox...\"

        # Install Firefox
        apt-get update -qq
        apt-get install -y firefox

        if [ \$? -eq 0 ]; then
            echo \"✓ Firefox installed\"
        else
            echo \"Failed to install Firefox\"
            exit 1
        fi

        # Create desktop icon for sweetagent user
        USER_DESKTOP=\"/home/sweetagent/Desktop\"
        mkdir -p \$USER_DESKTOP

        cat > \$USER_DESKTOP/firefox.desktop << EOF
[Desktop Entry]
Version=1.0
Name=Firefox Web Browser
Comment=Browse the World Wide Web
GenericName=Web Browser
Keywords=Internet;WWW;Browser;Web;Explorer
Exec=firefox %u
Terminal=false
X-MultipleArgs=false
Type=Application
Icon=firefox
Categories=GNOME;GTK;Network;WebBrowser;
MimeType=text/html;text/xml;application/xhtml+xml;application/xml;application/rss+xml;application/rdf+xml;image/gif;image/jpeg;image/png;x-scheme-handler/http;x-scheme-handler/https;x-scheme-handler/ftp;x-scheme-handler/chrome;video/webm;application/x-xpinstall;
StartupNotify=true
EOF

        # Set correct permissions
        chown sweetagent:sweetagent \$USER_DESKTOP/firefox.desktop
        chmod +x \$USER_DESKTOP/firefox.desktop

        # Mark as trusted (for newer Ubuntu/Xubuntu versions)
        sudo -u sweetagent gio set \$USER_DESKTOP/firefox.desktop metadata::trusted true 2>/dev/null || true

        echo \"✓ Firefox desktop icon created for sweetagent\"
    "' || true
    if [ $? -eq 0 ]; then
        echo "$host: SUCCESS"
    else
        echo "$host: FAILED"
    fi
done
echo "All hosts processed."
