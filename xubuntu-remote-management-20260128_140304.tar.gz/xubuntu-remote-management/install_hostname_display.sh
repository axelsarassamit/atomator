#!/bin/bash
set +e

for host in $(cat hosts.txt)
do
    echo "Processing $host..."
    sshpass -p 'sweetcom' ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 sweetagent@"$host" "
        echo sweetcom | sudo -S bash -c '
            # Install conky if not present
            if ! command -v conky &> /dev/null; then
                echo \"Installing conky on $host...\"
                apt-get update -qq
                apt-get install -y conky-all
            fi

            # Get all logged in users and users with home directories
            ALL_USERS=\$(ls /home)

            for user in \$ALL_USERS; do
                if [ -d \"/home/\$user\" ]; then
                    echo \"Setting up hostname display for user: \$user\"
                    USER_HOME=\"/home/\$user\"

                    # Stop any running conky instances for this user
                    pkill -u \$user conky 2>/dev/null || true
                    sleep 1

                    # Create conky config directory
                    mkdir -p \$USER_HOME/.config/conky
                    chown \$user:\$user \$USER_HOME/.config/conky

                    # Create conky config for hostname display
                    cat > \$USER_HOME/.config/conky/hostname.conf << '\''EOF'\''
conky.config = {
    alignment = '\''bottom_right'\'',
    background = true,
    border_width = 0,
    cpu_avg_samples = 2,
    default_color = '\''white'\'',
    default_outline_color = '\''white'\'',
    default_shade_color = '\''white'\'',
    draw_borders = false,
    draw_graph_borders = false,
    draw_outline = false,
    draw_shades = false,
    use_xft = true,
    font = '\''DejaVu Sans Mono:size=16'\'',
    gap_x = 15,
    gap_y = 50,
    minimum_height = 5,
    minimum_width = 150,
    net_avg_samples = 2,
    no_buffers = true,
    out_to_console = false,
    out_to_stderr = false,
    extra_newline = false,
    own_window = true,
    own_window_class = '\''Conky'\'',
    own_window_type = '\''dock'\'',
    own_window_transparent = false,
    own_window_argb_visual = true,
    own_window_argb_value = 200,
    own_window_hints = '\''undecorated,below,sticky,skip_taskbar,skip_pager'\'',
    stippled_borders = 0,
    update_interval = 60.0,
    uppercase = true,
    use_spacer = '\''none'\'',
    show_graph_scale = false,
    show_graph_range = false
}

conky.text = [[
\${font :bold:size=18}\${nodename_short}\${font}
]]
EOF

                    chown \$user:\$user \$USER_HOME/.config/conky/hostname.conf

                    # Create autostart entry
                    mkdir -p \$USER_HOME/.config/autostart
                    chown \$user:\$user \$USER_HOME/.config/autostart

                    cat > \$USER_HOME/.config/autostart/hostname-conky.desktop << EOF2
[Desktop Entry]
Type=Application
Name=Hostname Display
Exec=conky -c /home/\$user/.config/conky/hostname.conf
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true
Comment=Display hostname on desktop
EOF2

                    chown \$user:\$user \$USER_HOME/.config/autostart/hostname-conky.desktop

                    # Start conky for currently logged in users
                    if who | grep -q \"^\$user \"; then
                        USER_UID=\$(id -u \$user)
                        export DISPLAY=:0
                        export DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/\$USER_UID/bus
                        sudo -u \$user nohup conky -c \$USER_HOME/.config/conky/hostname.conf >/dev/null 2>&1 &
                        disown
                    fi

                    echo \"✓ Setup complete for \$user\"
                fi
            done

            echo \"Hostname display installed for all users\"
        '
    " || true
    if [ $? -eq 0 ]; then
        echo "$host: SUCCESS"
    else
        echo "$host: FAILED"
    fi
done
echo "All hosts processed."
