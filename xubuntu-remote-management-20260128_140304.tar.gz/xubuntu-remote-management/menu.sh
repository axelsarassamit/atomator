#!/bin/bash

# Colors for better readability
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
MAGENTA='\033[0;35m'
NC='\033[0m' # No Color

# Function to display header
show_header() {
    clear
    echo -e "${CYAN}╔════════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║          Remote System Management Script Menu                 ║${NC}"
    echo -e "${CYAN}╚════════════════════════════════════════════════════════════════╝${NC}"
    echo ""
}

# Function to pause
pause() {
    echo ""
    read -p "Press Enter to continue..."
}

# Function to run script
run_script() {
    local script_name=$1
    local script_desc=$2

    show_header
    echo -e "${GREEN}Running: ${script_desc}${NC}"
    echo -e "${BLUE}Script: ${script_name}${NC}"
    echo ""

    if [ -f "./${script_name}" ]; then
        bash "./${script_name}"
    else
        echo -e "${RED}Error: ${script_name} not found!${NC}"
    fi
    pause
}

# Main menu loop
while true; do
    show_header

    echo -e "${MAGENTA}═══════════════════════ SYSTEM UPDATES ═══════════════════════${NC}"
    echo -e "${YELLOW}1.${NC}  update_all.sh - Update all systems (apt update & upgrade)"
    echo -e "${YELLOW}2.${NC}  update_and_remove_all.sh - Update systems & remove old kernels"
    echo -e "${YELLOW}3.${NC}  disable_auto_updates.sh - Disable automatic updates on all hosts"
    echo ""

    echo -e "${MAGENTA}═════════════════════ SYSTEM MAINTENANCE ═════════════════════${NC}"
    echo -e "${YELLOW}4.${NC}  cleanup_all.sh - Clean cache, logs, trash, old files"
    echo -e "${YELLOW}5.${NC}  reboot.sh - Reboot all hosts"
    echo ""

    echo -e "${MAGENTA}═════════════════════ NETWORK MANAGEMENT ═════════════════════${NC}"
    echo -e "${YELLOW}6.${NC}  check_hosts.sh - Check which hosts are online/offline"
    echo -e "${YELLOW}7.${NC}  wol_all.sh - Wake up all computers (Wake-on-LAN)"
    echo -e "${YELLOW}8.${NC}  collect_mac_addresses.sh - Collect MAC addresses for WOL"
    echo -e "${YELLOW}9.${NC}  change_dns.sh - Change DNS servers (Cloudflare, Google, Amazon)"
    echo -e "${YELLOW}10.${NC} fix_static_ip.sh - Set current IP as static IP"
    echo -e "${YELLOW}11.${NC} require_sudo_network.sh - Require sudo password for network changes"
    echo -e "${YELLOW}12.${NC} speedtest_all.sh - Run internet speed test on all hosts"
    echo ""

    echo -e "${MAGENTA}══════════════════ HARDWARE INFORMATION ══════════════════════${NC}"
    echo -e "${YELLOW}13.${NC} collect_hardware_info.sh - Get manufacturer, model, CPU, disk info"
    echo -e "${YELLOW}14.${NC} collect_ram_info.sh - Collect RAM information from all hosts"
    echo ""

    echo -e "${MAGENTA}════════════════════ SOFTWARE INSTALLATION ═══════════════════${NC}"
    echo -e "${YELLOW}15.${NC} install_firefox.sh - Install Firefox browser with desktop icon"
    echo -e "${YELLOW}16.${NC} install_hostname_display.sh - Display hostname on desktop (conky)"
    echo ""

    echo -e "${MAGENTA}════════════════════ SYSTEM CONFIGURATION ════════════════════${NC}"
    echo -e "${YELLOW}17.${NC} set_wallpaper.sh - Set random wallpaper from wallpapers.txt"
    echo -e "${YELLOW}18.${NC} restrict_chromium_cpu.sh - Limit Chromium CPU usage to 50%"
    echo ""

    echo -e "${MAGENTA}═════════════════════════ UTILITIES ══════════════════════════${NC}"
    echo -e "${YELLOW}19.${NC} run_remote_command.sh - Execute custom command on all hosts"
    echo -e "${YELLOW}20.${NC} View hosts.txt - Display the list of managed hosts"
    echo -e "${YELLOW}21.${NC} Edit hosts.txt - Edit the list of managed hosts"
    echo ""

    echo -e "${RED}0.${NC}  Exit"
    echo ""
    echo -e "${CYAN}═══════════════════════════════════════════════════════════════${NC}"

    read -p "Enter your choice [0-21]: " choice
    echo ""

    case $choice in
        1)  run_script "update_all.sh" "Update All Systems" ;;
        2)  run_script "update_and_remove_all.sh" "Update & Remove Old Kernels" ;;
        3)  run_script "disable_auto_updates.sh" "Disable Automatic Updates" ;;
        4)  run_script "cleanup_all.sh" "System Cleanup" ;;
        5)  run_script "reboot.sh" "Reboot All Hosts" ;;
        6)  run_script "check_hosts.sh" "Check Host Status" ;;
        7)  run_script "wol_all.sh" "Wake-on-LAN" ;;
        8)  run_script "collect_mac_addresses.sh" "Collect MAC Addresses" ;;
        9)  run_script "change_dns.sh" "Change DNS Servers" ;;
        10) run_script "fix_static_ip.sh" "Fix Static IP" ;;
        11) run_script "require_sudo_network.sh" "Require Sudo for Network" ;;
        12) run_script "speedtest_all.sh" "Internet Speed Test" ;;
        13) run_script "collect_hardware_info.sh" "Collect Hardware Info" ;;
        14) run_script "collect_ram_info.sh" "Collect RAM Info" ;;
        15) run_script "install_firefox.sh" "Install Firefox" ;;
        16) run_script "install_hostname_display.sh" "Install Hostname Display" ;;
        17) run_script "set_wallpaper.sh" "Set Wallpaper" ;;
        18) run_script "restrict_chromium_cpu.sh" "Restrict Chromium CPU" ;;
        19) run_script "run_remote_command.sh" "Run Remote Command" ;;
        20)
            show_header
            echo -e "${GREEN}Contents of hosts.txt:${NC}"
            echo ""
            if [ -f "./hosts.txt" ]; then
                cat -n ./hosts.txt
            else
                echo -e "${RED}Error: hosts.txt not found!${NC}"
            fi
            pause
            ;;
        21)
            show_header
            echo -e "${GREEN}Editing hosts.txt${NC}"
            echo ""
            if [ -f "./hosts.txt" ]; then
                ${EDITOR:-nano} ./hosts.txt
            else
                echo -e "${RED}Error: hosts.txt not found!${NC}"
                pause
            fi
            ;;
        0)
            show_header
            echo -e "${GREEN}Exiting... Goodbye!${NC}"
            echo ""
            exit 0
            ;;
        *)
            show_header
            echo -e "${RED}Invalid choice! Please select 0-21.${NC}"
            sleep 2
            ;;
    esac
done
