#!/bin/bash
set +e
for host in $(cat hosts.txt)
do
    echo "Rebooting $host..."
    sshpass -p 'sweetcom' ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 sweetagent@"$host" 'echo sweetcom | sudo -S reboot' || true
    echo "$host: Reboot command sent"
done
echo "All hosts sent reboot command."
