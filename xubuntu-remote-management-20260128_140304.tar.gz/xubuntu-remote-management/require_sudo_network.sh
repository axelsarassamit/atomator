#!/bin/bash
set +e

for host in $(cat hosts.txt)
do
    echo "Processing $host..."
    sshpass -p 'sweetcom' ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 sweetagent@"$host" 'echo sweetcom | sudo -S bash -c "
        echo \"Configuring network settings to require sudo password...\"

        # Create polkit rule to require authentication for network settings
        cat > /etc/polkit-1/localauthority/50-local.d/require-auth-network.pkla << EOF
[Require password for network settings]
Identity=unix-user:*
Action=org.freedesktop.NetworkManager.*
ResultAny=auth_admin
ResultInactive=auth_admin
ResultActive=auth_admin
EOF

        # Also restrict nm-applet and network manager GUI tools
        cat > /etc/polkit-1/localauthority/50-local.d/restrict-network-manager.pkla << EOF
[Restrict NetworkManager Configuration]
Identity=unix-user:*
Action=org.freedesktop.NetworkManager.settings.modify.system;org.freedesktop.NetworkManager.settings.modify.own;org.freedesktop.NetworkManager.network-control
ResultAny=auth_admin
ResultInactive=auth_admin
ResultActive=auth_admin
EOF

        # Restart polkit to apply changes
        systemctl restart polkit 2>/dev/null || true

        echo \"✓ Network settings now require sudo/admin password\"
        echo \"✓ Users must authenticate as administrator to change network settings\"
    "' || true
    if [ $? -eq 0 ]; then
        echo "$host: SUCCESS"
    else
        echo "$host: FAILED"
    fi
done
echo "All hosts processed."
