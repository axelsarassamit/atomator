#!/bin/bash
set +e

for host in $(cat hosts.txt)
do
    echo "Processing $host..."
    sshpass -p 'sweetcom' ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 sweetagent@"$host" 'echo sweetcom | sudo -S bash -c "
        echo \"Setting up CPU restrictions for Chromium...\"

        # Install cpulimit if not present
        if ! command -v cpulimit &> /dev/null; then
            echo \"Installing cpulimit...\"
            apt-get update -qq
            apt-get install -y cpulimit
        fi

        # Get all users with home directories
        ALL_USERS=\$(ls /home)

        for user in \$ALL_USERS; do
            if [ -d \"/home/\$user\" ]; then
                echo \"Setting up CPU limit for user: \$user\"
                USER_HOME=\"/home/\$user\"

                # Create autostart directory
                mkdir -p \$USER_HOME/.config/autostart
                chown \$user:\$user \$USER_HOME/.config/autostart

                # Create CPU limit script for chromium and slack
                cat > \$USER_HOME/.local/bin/chromium-cpu-limit.sh << 'EOF'
#!/bin/bash
# Limit Chromium CPU usage to 50% per process and Slack to 25%
while true; do
    sleep 10
    # Limit Chromium processes
    for pid in \$(pgrep -u \$(whoami) chromium); do
        if ! pgrep -P \$pid cpulimit >/dev/null 2>&1; then
            cpulimit -p \$pid -l 50 -b >/dev/null 2>&1
        fi
    done
    # Limit Slack processes
    for pid in \$(pgrep -u \$(whoami) slack); do
        if ! pgrep -P \$pid cpulimit >/dev/null 2>&1; then
            cpulimit -p \$pid -l 25 -b >/dev/null 2>&1
        fi
    done
done
EOF

                mkdir -p \$USER_HOME/.local/bin
                chown \$user:\$user \$USER_HOME/.local/bin
                chown \$user:\$user \$USER_HOME/.local/bin/chromium-cpu-limit.sh
                chmod +x \$USER_HOME/.local/bin/chromium-cpu-limit.sh

                # Create autostart entry
                cat > \$USER_HOME/.config/autostart/chromium-cpu-limit.desktop << EOF2
[Desktop Entry]
Type=Application
Name=Chromium & Slack CPU Limiter
Exec=/home/\$user/.local/bin/chromium-cpu-limit.sh
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true
Comment=Limit Chromium and Slack CPU usage
EOF2

                chown \$user:\$user \$USER_HOME/.config/autostart/chromium-cpu-limit.desktop

                # Start the CPU limiter for currently logged in users
                if who | grep -q \"^\$user \"; then
                    # Kill any existing instances
                    pkill -u \$user -f chromium-cpu-limit.sh 2>/dev/null || true
                    sleep 1
                    # Start new instance
                    sudo -u \$user nohup \$USER_HOME/.local/bin/chromium-cpu-limit.sh >/dev/null 2>&1 &
                    disown
                fi

                echo \"✓ CPU limiter setup for \$user\"
            fi
        done

        echo \"✓ Chromium CPU usage limited to 50% per process\"
        echo \"✓ Slack CPU usage limited to 25% per process\"
        echo \"✓ CPU limiter will auto-start on login\"
    "' || true
    if [ $? -eq 0 ]; then
        echo "$host: SUCCESS"
    else
        echo "$host: FAILED"
    fi
done
echo "All hosts processed."
