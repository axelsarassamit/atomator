#!/bin/bash
set +e

echo "=== Remote Command Execution ==="
echo ""

if [ ! -f "hosts.txt" ]; then
    echo "ERROR: hosts.txt not found!"
    exit 1
fi

# Get command from user
echo "Enter the command you want to run on all hosts:"
read -p "Command: " REMOTE_COMMAND

if [ -z "$REMOTE_COMMAND" ]; then
    echo "ERROR: No command provided!"
    exit 1
fi

echo ""
echo "You are about to run the following command on all hosts:"
echo "  $REMOTE_COMMAND"
echo ""
read -p "Are you sure? (yes/no): " CONFIRM

if [ "$CONFIRM" != "yes" ]; then
    echo "Cancelled."
    exit 0
fi

echo ""
echo "=== Executing Command on All Hosts ==="
echo ""

# Create results file
RESULTS_FILE="remote_command_$(date +%Y%m%d_%H%M%S).txt"
echo "Remote Command Execution - $(date)" > "$RESULTS_FILE"
echo "Command: $REMOTE_COMMAND" >> "$RESULTS_FILE"
echo "======================================" >> "$RESULTS_FILE"
echo "" >> "$RESULTS_FILE"

SUCCESS=0
FAILED=0

for host in $(cat hosts.txt)
do
    # Skip empty lines and comments
    if [ -z "$host" ] || [[ "$host" =~ ^# ]]; then
        continue
    fi

    echo "Processing $host..."
    echo "--- $host ---" >> "$RESULTS_FILE"

    # Execute command
    OUTPUT=$(sshpass -p 'sweetcom' ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 sweetagent@"$host" "$REMOTE_COMMAND" 2>&1)

    if [ $? -eq 0 ]; then
        echo "  ✓ SUCCESS"
        echo "SUCCESS" >> "$RESULTS_FILE"
        ((SUCCESS++))
    else
        echo "  ✗ FAILED"
        echo "FAILED" >> "$RESULTS_FILE"
        ((FAILED++))
    fi

    echo "$OUTPUT" >> "$RESULTS_FILE"
    echo "" >> "$RESULTS_FILE"
done

TOTAL=$((SUCCESS + FAILED))

echo ""
echo "======================================" | tee -a "$RESULTS_FILE"
echo "Summary:" | tee -a "$RESULTS_FILE"
echo "  Total hosts: $TOTAL" | tee -a "$RESULTS_FILE"
echo "  Success: $SUCCESS" | tee -a "$RESULTS_FILE"
echo "  Failed: $FAILED" | tee -a "$RESULTS_FILE"
echo "" | tee -a "$RESULTS_FILE"
echo "Full results saved to: $RESULTS_FILE"
