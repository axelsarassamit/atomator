#!/bin/bash
set +e

# Get random wallpaper URL from wallpapers.txt
WALLPAPER_URL=$(grep -v '^#' wallpapers.txt | grep -v '^$' | shuf -n 1)

if [ -z "$WALLPAPER_URL" ]; then
    echo "No wallpaper URLs found in wallpapers.txt"
    exit 1
fi

echo "Selected wallpaper: $WALLPAPER_URL"
WALLPAPER_NAME=$(basename "$WALLPAPER_URL")

for host in $(cat hosts.txt)
do
    echo "Processing $host..."
    sshpass -p 'sweetcom' ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 sweetagent@"$host" "
        echo sweetcom | sudo -S bash -c '
            wget -q -O /tmp/$WALLPAPER_NAME \"$WALLPAPER_URL\"
            if [ \$? -ne 0 ]; then
                echo \"Failed to download wallpaper\"
                exit 1
            fi

            # Get all logged in users
            for user in \$(who | awk '\''{print \$1}'\'' | sort -u); do
                echo \"Setting wallpaper for user: \$user\"
                USER_HOME=\$(eval echo ~\$user)
                cp /tmp/$WALLPAPER_NAME \$USER_HOME/wallpaper.jpg
                chown \$user:\$user \$USER_HOME/wallpaper.jpg

                USER_UID=\$(id -u \$user)
                export DISPLAY=:0
                export DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/\$USER_UID/bus

                sudo -u \$user xfconf-query -c xfce4-desktop -p /backdrop/screen0/monitoreDP-1/workspace0/last-image -s \$USER_HOME/wallpaper.jpg 2>/dev/null
                sudo -u \$user xfconf-query -c xfce4-desktop -p /backdrop/screen0/monitor0/workspace0/last-image -s \$USER_HOME/wallpaper.jpg 2>/dev/null
                sudo -u \$user xfconf-query -c xfce4-desktop -p /backdrop/screen0/monitorVGA-1/workspace0/last-image -s \$USER_HOME/wallpaper.jpg 2>/dev/null
                sudo -u \$user xfconf-query -c xfce4-desktop -p /backdrop/screen0/monitorHDMI-1/workspace0/last-image -s \$USER_HOME/wallpaper.jpg 2>/dev/null
                sudo -u \$user xfconf-query -c xfce4-desktop -p /backdrop/screen0/monitorDP-1/workspace0/last-image -s \$USER_HOME/wallpaper.jpg 2>/dev/null

                # Force refresh the desktop
                sudo -u \$user xfdesktop --reload 2>/dev/null &
                sudo -u \$user xfconf-query -c xfce4-desktop -p /backdrop/screen0/monitoreDP-1/workspace0/last-image -s \$USER_HOME/wallpaper.jpg 2>/dev/null
                sudo -u \$user xfconf-query -c xfce4-desktop -p /backdrop/screen0/monitor0/workspace0/last-image -s \$USER_HOME/wallpaper.jpg 2>/dev/null
            done

            rm -f /tmp/$WALLPAPER_NAME
            echo \"Wallpaper set for all active users\"
        '
    " || true
    if [ $? -eq 0 ]; then
        echo "$host: SUCCESS"
    else
        echo "$host: FAILED"
    fi
done
echo "All hosts processed."
