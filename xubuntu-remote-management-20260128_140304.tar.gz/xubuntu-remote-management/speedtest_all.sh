#!/bin/bash
set +e

# Create results file with timestamp
RESULTS_FILE="speedtest_results_$(date +%Y%m%d_%H%M%S).txt"
echo "=== Speedtest Results ===" > "$RESULTS_FILE"
echo "Date: $(date)" >> "$RESULTS_FILE"
echo "======================================" >> "$RESULTS_FILE"
echo "" >> "$RESULTS_FILE"

for host in $(cat hosts.txt)
do
    echo "Processing $host..."
    echo "--- $host ---" >> "$RESULTS_FILE"

    sshpass -p 'sweetcom' ssh -o StrictHostKeyChecking=no -o ConnectTimeout=10 sweetagent@"$host" 'echo sweetcom | sudo -S bash -c "
        echo \"Installing speedtest-cli if not present...\"

        # Install speedtest-cli if not installed
        if ! command -v speedtest-cli &> /dev/null; then
            apt-get update -qq
            apt-get install -y speedtest-cli
            echo \"✓ speedtest-cli installed\"
        else
            echo \"✓ speedtest-cli already installed\"
        fi

        # Run speedtest
        echo \"Running speedtest on $host...\"
        speedtest-cli --simple
    "' >> "$RESULTS_FILE" 2>&1 || echo "FAILED to test $host" >> "$RESULTS_FILE"

    echo "" >> "$RESULTS_FILE"

    if [ $? -eq 0 ]; then
        echo "$host: SUCCESS"
    else
        echo "$host: FAILED"
    fi
done

echo "======================================" >> "$RESULTS_FILE"
echo "All tests completed: $(date)" >> "$RESULTS_FILE"
echo ""
echo "All hosts processed."
echo "Results saved to: $RESULTS_FILE"
cat "$RESULTS_FILE"
