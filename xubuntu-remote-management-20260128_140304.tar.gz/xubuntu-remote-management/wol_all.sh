#!/bin/bash
set +e

# Check if wakeonlan is installed
if ! command -v wakeonlan &> /dev/null; then
    echo "wakeonlan is not installed. Installing..."
    sudo apt-get update -qq
    sudo apt-get install -y wakeonlan
fi

# Find the most recent MAC address file
MAC_FILE=$(ls -t mac_addresses_*.txt 2>/dev/null | head -n1)

if [ -z "$MAC_FILE" ]; then
    echo "ERROR: No MAC address file found!"
    echo "Please run ./collect_mac_addresses.sh first to collect MAC addresses."
    exit 1
fi

echo "Using MAC address file: $MAC_FILE"
echo "=== Sending Wake-on-LAN packets ==="
echo ""

# Count total devices
TOTAL_DEVICES=0
while IFS='|' read -r ip hostname device mac; do
    if [[ "$ip" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+ ]]; then
        mac=$(echo "$mac" | xargs)
        if [ ! -z "$mac" ] && [ "$mac" != "-" ]; then
            ((TOTAL_DEVICES++))
        fi
    fi
done < "$MAC_FILE"

echo "Found $TOTAL_DEVICES devices with MAC addresses"
echo ""

# Send WOL packets 3 times per device for reliability
CURRENT=0
while IFS='|' read -r ip hostname device mac; do
    # Skip header lines and empty lines
    if [[ "$ip" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+ ]]; then
        # Trim whitespace
        ip=$(echo "$ip" | xargs)
        hostname=$(echo "$hostname" | xargs)
        mac=$(echo "$mac" | xargs)

        if [ ! -z "$mac" ] && [ "$mac" != "-" ]; then
            ((CURRENT++))
            echo "[$CURRENT/$TOTAL_DEVICES] Waking up: $ip ($hostname) - MAC: $mac"

            # Send WOL packet 3 times for reliability
            SUCCESS=0
            for i in 1 2 3; do
                wakeonlan "$mac" &>/dev/null
                if [ $? -eq 0 ]; then
                    ((SUCCESS++))
                fi
                # Small delay between retries
                sleep 0.2
            done

            if [ $SUCCESS -eq 3 ]; then
                echo "  ✓ WOL packets sent successfully (3x)"
            else
                echo "  ⚠ WOL packets partially sent ($SUCCESS/3)"
            fi

            # Brief delay before next device
            sleep 0.3
        fi
    fi
done < "$MAC_FILE"

echo ""
echo "=== All WOL packets sent ==="
echo ""
echo "Waiting 10 seconds before checking status..."
sleep 10

echo ""
echo "=== Checking which devices are now online ==="
ONLINE=0
OFFLINE=0

while IFS='|' read -r ip hostname device mac; do
    if [[ "$ip" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+ ]]; then
        ip=$(echo "$ip" | xargs)
        hostname=$(echo "$hostname" | xargs)
        mac=$(echo "$mac" | xargs)

        if [ ! -z "$mac" ] && [ "$mac" != "-" ]; then
            ping -c 1 -W 1 "$ip" &>/dev/null
            if [ $? -eq 0 ]; then
                echo "  ✓ $ip ($hostname) - ONLINE"
                ((ONLINE++))
            else
                echo "  ✗ $ip ($hostname) - Still offline (may need more time)"
                ((OFFLINE++))
            fi
        fi
    fi
done < "$MAC_FILE"

echo ""
echo "=== Summary ==="
echo "Online: $ONLINE/$TOTAL_DEVICES"
echo "Offline: $OFFLINE/$TOTAL_DEVICES"
echo ""
echo "Note: Some devices may take 30-60 seconds to fully boot up."
echo "Run this script again or ping the offline devices in a minute."
